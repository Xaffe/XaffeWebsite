module.exports = [
	"/index/",
	"/stock/",
	"/404/",
	"/",
	"/404.html"
]